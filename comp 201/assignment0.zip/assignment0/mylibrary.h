#ifndef MYLIBRARY_H
#define MYLIBRARY_H
int wrapper();
#endif // MYLIBRARY_H