#ifndef MYPROGRAM_H
#define MYPROGRAM_H

int sum_of_1_to_n(int n);
int sum_of_even_numbers(int *array, int count);
int max_of_numbers(int *array, int count);
int reversed_number(int number);
int is_prime(int number);
int count_primes(int start, int end);
char alphabet_index(int index);

#endif // MYPROGRAM_H