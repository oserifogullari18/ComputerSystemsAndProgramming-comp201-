#include "mylibrary.h"
int sum_of_1_to_n(int n)
{
	int sum = 0;

	//TODO: sum all numbers from 1 to n
	int i;
	for(i=0; i<=n; i++){
		sum += i;
	}

	return sum;
}

int sum_of_even_numbers(int *array, int count)
{
	int sum = 0;
	for (int i=0;i<count;++i)
	{
		//TODO: only add even numbers, e.g., 4. Skip odd numbers, e.g., 3
		if(array[i]%2 == 0){
			sum += array[i];
		}
		
	}
	return sum;
}

int max_of_numbers(int *array, int count)
{
	//TODO: return the maximum number from the array
	int max = array[0];
	int i;
	for(i=0; i<count; i++){
		if(array[i]> max){
			max= array[i];
		}
	}
	return max;
}

int reversed_number(int number)
{
	int reversed = 0;

	//TODO: if input is 12345, return 54321
	while(number != 0){
		reversed = (reversed * 10) + (number % 10);
		number = number/10;
	}

	return reversed;
}

int is_prime(int number)
{
	//TODO: return 1 if the input number is prime, otherwise 0
	int i;
	for(i=2; i<number; i++){
		if(number%i == 0){
			return 0;
		}
	}
	return 1;
}

int count_primes(int start, int end)
{
	//TODO: return the count of prime numbers in range [start, end] inclusive.
	int counter = 0;
	int i;
	for(i = start; i <= end; i++){
		int j;
		for(j=2; j<i; j++){
			if(i%j == 0){
				break;
			}
			counter++;
		}
	}
	return counter;
}


char alphabet_index(int index)
{
	//TODO: for index 0, return A. index 1, B, etc. until 25 for Z.
	//if index is out of range, return space ' '.
	switch (index)
	{
	case 0 :
		return 'A';
	case 1 :
		return 'B';
	case 2 :
		return 'C';
	case 3 :
		return 'D';
	case 4 :
		return 'E';
	case 5 :
		return 'F';
	case 6 :
		return 'G';
	case 7 :
		return 'H';
	case 8 :
		return 'I';
	case 9 :
		return 'J';
	case 10 :
		return 'K';
	case 11 :
		return 'L';
	case 12 :
		return 'M';
	case 13 :
		return 'N';
	case 14 :
		return 'O';
	case 15 :
		return 'P';
	case 16 :
		return 'Q';
	case 17 :
		return 'R';
	case 18 :
		return 'S';
	case 19 :
		return 'T';
	case 20 :
		return 'U';
	case 21 :
		return 'V';
	case 22 :
		return 'W';
	case 23 :
		return 'X';
	case 24 :
		return 'Y';
	case 25 :
		return 'Z';
	default:
		return ' ';
	}

}

