#include <stdlib.h>

int ask_number(); //asks the user to enter a integer between 0-10 & returns it
void print_result(int result); //prints the given integer parameter