#include "io.h"
#include "f.h"

int main(void){
	print_result(calculate_f(ask_number()));
}