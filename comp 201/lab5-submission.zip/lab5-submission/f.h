#include <stdlib.h>

int calculate_f(int x);