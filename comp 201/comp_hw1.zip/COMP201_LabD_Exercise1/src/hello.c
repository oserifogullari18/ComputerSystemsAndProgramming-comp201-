#include <stdio.h> 
  
int main(void)
{
    printf("Welcome to the COMP201 Lab01\n");
}
